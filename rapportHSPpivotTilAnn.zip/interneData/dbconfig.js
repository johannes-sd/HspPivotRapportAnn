module.exports = dboptions =  {
        userName: "stream",
        password: "stream",
        server: "daxproddb.sd.no" //,
    }