module.exports = function sqltext(startdato, sluttdato) {
var rappDatoStartFormatert = startdato;
var rappDatoSluttFormatert = sluttdato;

return `
    select t.CodeSEN, t.MERKENAVN, t.FORSENDELSESMÅTE, COUNT(t.FORSENDELSESMÅTE) as antall from 
        (select g.CodeSEN as CodeSEN, SUBSTRING(g.ParcelID, 5,3) AS MERKENAVN, 'FORSENDELSESMÅTE' = 
        CASE 
            WHEN g.Weight >= 2 AND g.CodeCSE = 'Mypack Home Stor' THEN 'HOME SMALL STOR' 
            WHEN g.Weight < 2 AND g.CodeCSE = 'Mypack Home Small' THEN 'HOME SMALL LITEN'
            WHEN g.CodeCSE = 'B-post' THEN 'HOME SMALL LITEN' 
            ELSE g.CodeCSE 
        END
    from ( 
        select distinct(rt.CodeSEN) as CodeSEN, p.ParcelID as 'ParcelID', cs.Description as 'CodeCSE', s.Weight as 'Weight' from Centiro.dbo.parcels p
        inner join Centiro.dbo.shipments s
        on p.idSHP = s.idSHP 
        inner join Centiro.dbo.CarrierServices cs
        on p.CodeCSE = cs.CodeCSE 
        inner join DAXAUX.dbo.PackageReturnTable rt 
        on p.SequenceNoSSCC = rt.SequenceNoSSCC 
        WHERE rt.regdato >= '${rappDatoStartFormatert}' AND 
        rt.regdato < '${rappDatoSluttFormatert}' 
        AND rt.status <> '' 
        AND s.LabelStatus = '10' ) g 
    ) t 
    GROUP BY t.MERKENAVN, t.FORSENDELSESMÅTE, t.CodeSEN 
    Order by MERKENAVN, FORSENDELSESMÅTE`;

};