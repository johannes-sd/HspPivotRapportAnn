module.exports = mailOptions = {
    from: '<itdrift@sd.no>',
    //to: 'ann.harsaker@sd.no, johannes@sd.no',
    to: 'johannes@sd.no',
    subject : 'HSP-FORSENDELSESMAATER',
    text: 'HSP FORSENDELSESMÅTER',
    html: ""
};

