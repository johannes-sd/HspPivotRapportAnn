module.exports = transportOptions = {
        //host: 'send.one.com',
        host: 'smtpa.sd.no',
        auth: {
            user: 'johannes@sd.no',
            pass : 'svensker18'
        },
        secure: false,
        tls: {rejectUnauthorized: false},
        debug: true
}